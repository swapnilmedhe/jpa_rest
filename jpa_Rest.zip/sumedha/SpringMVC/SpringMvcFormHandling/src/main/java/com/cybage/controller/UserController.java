package com.cybage.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.model.User;

public class UserController {
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ModelAndView user(){
		return new ModelAndView("user","user",new User());
	}
	
	@RequestMapping(value="/success",method=RequestMethod.POST)
	public String success(@ModelAttribute User user,ModelMap model){
		if(user.getName().equals(user.getPassword())){
			System.out.println("success");
			model.addAttribute("mesg",user.getName());
			return "success";
		}
		else{
			model.addAttribute("error","Invalid credentials");
			return "user";
		}
	}

}
