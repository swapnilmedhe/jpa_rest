package com.cybage.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.model.Employee;

@Service
public class EmpService {
	
	List<Employee> emp1=new ArrayList<Employee>();
	
	public void addEmployee(Employee e){
		emp1.add(e);
	}
	
	public List<Employee> showEmpl(){
		return emp1;
	}
	
	public Employee editEmployee(Employee e)
	{
		return e;
	}
}
