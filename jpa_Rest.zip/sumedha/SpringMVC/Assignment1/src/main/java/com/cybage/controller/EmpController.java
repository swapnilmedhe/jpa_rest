package com.cybage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.model.Employee;
import com.cybage.service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	EmpService es;
	
	@RequestMapping(value="/show",method=RequestMethod.GET )
	public ModelAndView addEmployee(){
		
		ModelMap mp=new ModelMap();
		mp.addAttribute("emp", new Employee());
		return new ModelAndView("addEmployee", mp);
		
	}
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public ModelAndView getEmp(@ModelAttribute Employee emp){
			
		es.addEmployee(emp);
		ModelMap mp = new ModelMap();
		mp.addAttribute("emp",es.showEmpl());
		return new ModelAndView("showEmp", mp);
		
	}
	
	
	@RequestMapping(value="/edit", method=RequestMethod.GET)
	public ModelAndView editEmp(@ModelAttribute Employee emp)
	{
		es.editEmployee(emp);
		ModelMap mp = new ModelMap();
		mp.addAttribute("emp",es.editEmployee(emp));
		return new ModelAndView("editEmployee", mp);
		
	}
	

	
}
