package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.Person;
import com.cybage.repository.PersonRepository;

@Component
public class PersonServiceImpl implements PersonService
{
    @Autowired
    private  PersonRepository  personRepository;
    
    @Transactional
    public  Person getPersonById(int id)
    {
        return  personRepository.findOne(id);
    }
    @Transactional
    public HttpStatus savePerson(Person p)
    {
    	return (HttpStatus) personRepository.save(p);
    }
    @Transactional
    public HttpStatus updatePerson(Person p)
    {
    	return (HttpStatus) personRepository.save(p);
      
    }
    @Transactional
    public HttpStatus deletePerson(int id)
    {
    	return (HttpStatus)personRepository.delete(id);
    }
    @Transactional
    public List<Person> getAllPersons()
    {
       return personRepository.findAll();
    }
}
