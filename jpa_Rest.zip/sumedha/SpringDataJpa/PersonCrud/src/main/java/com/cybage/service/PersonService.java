package com.cybage.service;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.cybage.model.Person;

public interface PersonService {
	
	public  Person getPersonById(int id);
    public HttpStatus savePerson(Person p);
    public HttpStatus updatePerson(Person p);
    public HttpStatus deletePerson(int id);
    public abstract List<Person> getAllPersons();
}
