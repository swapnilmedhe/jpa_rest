package com.cybage.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.Employee;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class EmployeeDAOImpl implements EmployeeDAO
{

    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public void createEmployee(Employee emp)
    {
        entityManager.persist(emp);
    }

    @Override
    public Employee getEmployeeById(long id)
    {
        return entityManager.find(Employee.class,id);
    }

    @Override
    public List<Employee> getAllEmployees()
    {
        return entityManager.createQuery("select emp from Employee emp").getResultList();
    }

    @Override
    public void updateEmployee(Employee emp)
    {
        entityManager.merge(emp);
    }

    @Override
    public void deleteEmployee(long id)
    {
        Employee e = entityManager.find(Employee.class,id);
        entityManager.remove(e);
    }
}
