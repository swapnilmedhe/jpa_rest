package com.cybage.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cybage.model.Employee;;

public class SpringRestTemplateClient
{
    public static final String REST_BASE_URI = "http://localhost:7070/SpringRestHibernate";
   
    static RestTemplate restTemplate = new RestTemplate();
    
    /**POST**/
    public static void createEmployee()
    {
        Employee emp = new Employee();
        emp.setId(5);
        emp.setName("Sameer");
        emp.setSalary(24000);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        
        HttpEntity<Employee> entity = new HttpEntity<>(emp,headers);
        restTemplate.postForObject(REST_BASE_URI+"/create", entity,Employee.class);
    }
    
    /**GET**/
    private static void getEmployee(int id)
    {
        Employee emp = restTemplate.getForObject(REST_BASE_URI+"/emp/"+id, Employee.class);
        System.out.println("**** Employee with id : "+id+"****");
        System.out.println("Id :"+emp.getId()+"    Name : "+emp.getName()+"   Salary : "+emp.getSalary());
    }
    public static void getAllEmployees()
    {
       

        List<Map<String, Object>> empList = restTemplate.getForObject(REST_BASE_URI + "/emps", List.class);
        if (empList != null)
        {
            System.out.println("**** All Employees ****");
            for (Map<String, Object> map : empList)
            {
                System.out.println("Id : id=" + map.get("id") + "   Name=" + map.get("name") + "   Salary="
                        + map.get("salary"));
            }
        } else
        {
            System.out.println("No Employee exist!!");
        }
    }
    
    /**PUT**/
    public static void updateEmployee()
    {
        Employee emp = new Employee();
        emp.setId(5);
        emp.setName("Sameer");
        emp.setSalary(35000);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Employee> entity = new HttpEntity<>(emp,headers);
        
        restTemplate.put(REST_BASE_URI + "/update", entity,Employee.class);
    }
    
    /**DELETE**/
    public static void deleteEmployee(int id)
    {
        restTemplate.delete(REST_BASE_URI + "/delete/"+id);
    }
    public static void main(String args[])
    {
        createEmployee();
        
        getAllEmployees();
        getEmployee(2);
        
        updateEmployee();
        
        deleteEmployee(5);
    }
}
