package com.cybage.dao;

import java.util.List;

import com.cybage.model.Employee;

public interface EmployeeDAO
{
    public void createEmployee(Employee emp);
    
    public Employee getEmployeeById(long id);
    public List<Employee> getAllEmployees();
    
    public void updateEmployee(Employee emp);
    
    public void deleteEmployee(long id);
}
