package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.dao.EmployeeDAOImpl;
import com.cybage.model.Employee;

@RestController
public class EmployeeController
{
    @Autowired
    private EmployeeDAOImpl empDAOImpl;
    
    /*** Creating a new Employee ***/
    @RequestMapping(value="/create", method=RequestMethod.POST, 
            produces="application/json", consumes="application/json")
    
    public void createEmployee(@RequestBody Employee emp)
    {
        empDAOImpl.createEmployee(emp);
    }
    
    /*** Retrieve a single Employee ***/
    @RequestMapping(value="/emp/{id}",produces="application/json",
            method=RequestMethod.GET)
    public Employee getEmployeeById(@PathVariable("id") long id)
    {
        Employee emp = empDAOImpl.getEmployeeById(id);
        return emp;
    }
    
    /*** Retrieve all Employees ***/
    @RequestMapping(value="/emps",produces="application/json",
            method=RequestMethod.GET)
    public List<Employee> getAllEmployees()
    {
        List<Employee> empList = empDAOImpl.getAllEmployees();
        return empList;
    }
    
    /*** Update an Employee ***/
    @RequestMapping(value="/update", method=RequestMethod.PUT, 
            produces="application/json", consumes="application/json")
    public void updateEmployee(@RequestBody Employee emp)
    {
        empDAOImpl.updateEmployee(emp);
    }
    
    /*** Delete an Employee ***/
    @RequestMapping(value="/delete/{id}",produces="application/json")
    public void deleteEmployee(@PathVariable("id") long id)
    {
        empDAOImpl.deleteEmployee(id);
    }
}
