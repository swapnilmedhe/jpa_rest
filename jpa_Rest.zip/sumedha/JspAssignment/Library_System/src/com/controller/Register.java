package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DaoImplementation;

import pojo.User;



/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	String st;
	

	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String password=request.getParameter("pass");
		String email=request.getParameter("email");
		String gender=request.getParameter("gender");
		
		try {
			
			if(name.equals("sameer") && password.equals("Test@123"))
			{
				HttpSession session=request.getSession();
				session.setAttribute("name",name);
				RequestDispatcher rd=request.getRequestDispatcher("bookHandle.jsp");
				rd.include(request, response);
				
			}
			
			if(name!="sameer") {
			
			   DaoImplementation dao=new DaoImplementation();
		       User u=new User(name, "user", email,password, gender);
			   st = dao.registerUser(u);
			
			System.out.println("####ST"+ st);
			}
			if(st.equals("success")) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('User Registered Successfully!!!!!');");
				out.println("</script>");
				HttpSession session=request.getSession();
				session.setAttribute("name",name);
				RequestDispatcher rd=request.getRequestDispatcher("Index.jsp");
				rd.include(request, response);
			}
			
			else
			{
				//out.println("<p>User Already Exist</p>");
				request.setAttribute("errMessage", st); //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
				request.getRequestDispatcher("Index.jsp").forward(request, response);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		out.close();
		}

}
