package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DaoImplementation;

import pojo.Book;
import pojo.User;

/**
 * Servlet implementation class Insert_Delete
 */
@WebServlet("/Insert_Delete")
public class Insert_Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       String st;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Insert_Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 DaoImplementation dao1=new DaoImplementation();
	       Book b1=new Book();
		   try {

		       PrintWriter out=response.getWriter();
			st = dao1.showBooks(b1,request);
			
            System.out.println(st);
			if(st.equals("showDetails")) {
			
				RequestDispatcher rd=request.getRequestDispatcher("UserHome.jsp");
				rd.forward(request, response);
			}
			
			
		}
		   catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        PrintWriter out=response.getWriter();
		
		String tittle=request.getParameter("tittle");
		String author=request.getParameter("author");
		int rating=Integer.parseInt(request.getParameter("rating"));
		
		
			try {
			
			   DaoImplementation dao=new DaoImplementation();
		       Book b=new Book(tittle, author, rating);
			   st = dao.insertBook(b);
			
			System.out.println("####ST"+ st);
			
			if(st.equals("BookInserted")) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Inserted Successfully!!!!!');");
				out.println("</script>");
				RequestDispatcher rd=request.getRequestDispatcher("Insert.jsp");
				rd.include(request, response);
			}
			
			else
			{
				
				request.setAttribute("errMessage", st); //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
				request.getRequestDispatcher("Insert.jsp").forward(request, response);

			}
		} catch (SQLException e)
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		out.close();
		}

		
	}


