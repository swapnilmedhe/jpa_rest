package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DaoImplementation;

import pojo.Book;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
      String st; 
   
    public Delete() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		DaoImplementation dao1=new DaoImplementation();
	       Book b1=new Book();
		   try {

		       PrintWriter out=response.getWriter();
			 st = dao1.showBooks(b1,request);
			
            System.out.println(st);
			if(st.equals("showDetails")) {
				
				RequestDispatcher rd=request.getRequestDispatcher("bookHandle.jsp");
				rd.forward(request, response);
				
			}
		   }
			   catch (SQLException e) {
		
				e.printStackTrace();
			}
		   
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
