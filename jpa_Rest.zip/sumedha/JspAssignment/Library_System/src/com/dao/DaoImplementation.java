package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbconnection.*;
import pojo.Book;
import pojo.User;

public class DaoImplementation {

	
public  String registerUser(User u) throws SQLException {
		
		int st=0;
		
			Connection con=ConnectionProvider.getConnection();;
			
			PreparedStatement ps1=con.prepareStatement("select * from registered_user where email=?");
			ps1.setString(1,u.getEmail());
			                ResultSet rs=(ResultSet) ps1.executeQuery();
			                if(rs.next())
			                {
			                    
			                	System.out.println("user already exist!!!!!");
			                	return "User Already Exist";
			                    }
			                else{
			                	PreparedStatement ps2=con.prepareStatement("insert into registered_user( name,password,role,email,gender) values(?,?,?,?,?)");
			        			
			        			ps2.setString(1, u.getName());
			        			ps2.setString(2,u.getPassword());
			        			ps2.setString(3,u.getRole());
			        			ps2.setString(4,u.getEmail());
			        			ps2.setString(5,u.getGender());
			        			
			        			
			        			
			        			st=ps2.executeUpdate();
			        			
			        			
			        			System.out.println("Email "+u.getEmail());
			        			
			        		
			        			
			        	
			        		//System.out.println(u.getId());
			        			//con.close();
			        			return "success";
			                }
			                }


public  String insertBook(Book b) throws SQLException {
	
	int st1=0;
	
		Connection con=ConnectionProvider.getConnection();;
		
		PreparedStatement ps=con.prepareStatement("select * from book where BName=?");
		ps.setString(1, b.getbName());
		                ResultSet rs=(ResultSet) ps.executeQuery();
		                if(rs.next())
		                {
		                    
		                	System.out.println("book already exist!!!!!");
		                	return "book Already Exist";
		                    }
		                else{
		                	PreparedStatement ps1=con.prepareStatement("insert into book( BName,BAuthor,BRating) values(?,?,?)");
		        			
		        			ps1.setString(1, b.getbName());
		        			ps1.setString(2,b.getbAuthor());
		        			ps1.setInt(3,b.getbReview());
		        			
		        			st1=ps1.executeUpdate();
		        			
		        			
		        			System.out.println("Book Name "+b.getbName());
		        			
		        			//con.close();
		        			return "BookInserted";
		        		}

}

public  String showBooks(Book b,HttpServletRequest request) throws SQLException {
	
	int st1=0;
	
		Connection con=ConnectionProvider.getConnection();;
		
		PreparedStatement ps=con.prepareStatement("select * from book");

		                ResultSet rs=(ResultSet) ps.executeQuery();
		                    
		                	System.out.println(rs);
		                	
							HttpSession session=request.getSession();
							System.out.println(session);
							session.setAttribute("show", rs);
		                	return "showDetails";
		               
}
}
   
	
	
	
	
	

