package com.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import dbconnection.ConnectionProvider;
import pojo.User;


public class LoginDao {
public String authenticateUser(User u)
{

String userName = u.getName(); //Keeping user entered values in temporary variables.
String password = u.getPassword();

System.out.println(userName);
System.out.println(password);

Connection con = null;
Statement statement = null;
ResultSet resultSet = null;

String userNameDB = "";
String passwordDB = "";

	try
	{
		if(userName.equals("sameer") && password.equals("Test@123")) {
			
			return "SUCCESSAdmin";
		}
		else {	
	con = ConnectionProvider.getConnection(); //establishing connection
	//String sql2 = "SELECT * FROM  user WHERE Temail=? and Tpassword=?";
	PreparedStatement pst = con.prepareStatement("select * from registered_user where name=? and password=?");


	pst.setString(1,u.getEmail());
	pst.setString(2,u.getPassword());
	ResultSet rs2 = pst.executeQuery();

	while(rs2.next())
	{
		System.out.println("In user");
		
	}
	return "SUCCESSUser";
}
	}
catch(SQLException e)
{
e.printStackTrace();
}
return "Invalid user credentials"; // Just returning appropriate message otherwise
}
}


