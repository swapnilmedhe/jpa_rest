package pojo;

public class Book {
String bName,bAuthor;
int bId,bReview;



public Book() {
	super();
}
public String getbName() {
	return bName;
}
public void setbName(String bName) {
	this.bName = bName;
}
public String getbAuthor() {
	return bAuthor;
}
public void setbAuthor(String bAuthor) {
	this.bAuthor = bAuthor;
}
public int getbId() {
	return bId;
}
public void setbId(int bId) {
	this.bId = bId;
}
public int getbReview() {
	return bReview;
}
public void setbReview(int bReview) {
	this.bReview = bReview;
}
public Book(String bName, String bAuthor, int bReview) {
	super();
	this.bName = bName;
	this.bAuthor = bAuthor;
	this.bId = bId;
	this.bReview = bReview;
}
@Override
public String toString() {
	return "Book [bName=" + bName + ", bAuthor=" + bAuthor + ", bId=" + bId + ", bReview=" + bReview + "]";
}


}
